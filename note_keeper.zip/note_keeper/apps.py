from django.apps import AppConfig


class NoteKeeperConfig(AppConfig):
    name = 'note_keeper'
